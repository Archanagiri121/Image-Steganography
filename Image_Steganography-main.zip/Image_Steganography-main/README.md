# Image_Steganography

Embedd any kind of file into an image using this app and extract the file whenever you want using the same app.
<img height="250px" src="https://i.pinimg.com/originals/29/25/d4/2925d4a7177ace6b736800cced78d90b.gif" alt=""/>

#Dependencies
1. OpenCv2 
2. Os module of python


